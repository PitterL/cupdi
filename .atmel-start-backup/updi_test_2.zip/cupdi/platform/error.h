#ifndef __ERROR_H
#define __ERROR_H

#include <errno.h>

#define ERROR_PTR -1

#endif
