/*
 * hexfile.h
 *
 * Created: 16/08/2020 09:42:13
 *  Author: A18425
 */ 


#ifndef HEXFILE_H_
#define HEXFILE_H_

extern const char* hexarry[];

void hexarray_seek_begin();
char *hexarray_gets(char *str, int n, const char *fp[]);

#endif /* HEXFILE_H_ */