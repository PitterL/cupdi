#include <atmel_start.h>
#include "cupdi/cupdi.h"
#include "hex_file/hexfile.h"

int main(void)
{
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();
	
	
	
	cupdi_operate(hexarry);

	/* Replace with your application code */
	while (1) {
	}
}
