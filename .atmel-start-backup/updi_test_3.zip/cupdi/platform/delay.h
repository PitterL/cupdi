#ifndef __LINUX_TIME_H
#define __LINUX_TIME_H

void msleep(int ms);

#endif
