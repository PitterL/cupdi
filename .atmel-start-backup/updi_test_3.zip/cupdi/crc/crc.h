unsigned char calc_crc8(const unsigned char *base, int size);
unsigned int calc_crc24(const unsigned char *base, int size);